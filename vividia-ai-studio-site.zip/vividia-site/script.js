const form=document.getElementById("videoForm");
const resultPanel=document.getElementById("resultPanel");
const resultText=document.getElementById("resultText");
const toast=document.getElementById("toast");
let currentBrief="";
document.getElementById("year").textContent=new Date().getFullYear();

function showToast(message){
  toast.textContent=message;
  toast.classList.add("show");
  window.setTimeout(()=>toast.classList.remove("show"),2600);
}

form.addEventListener("submit",(event)=>{
  event.preventDefault();
  const prompt=document.getElementById("prompt").value.trim();
  if(prompt.length<12){showToast("Décrivez votre idée avec un peu plus de détails.");return;}
  const style=document.getElementById("style").value;
  const duration=document.getElementById("duration").value;
  const language=document.getElementById("language").value;
  const format=document.getElementById("format").value;
  currentBrief=[
    "VIVIDIA AI STUDIO — BRIEF DE PRODUCTION",
    "",
    "Idée : "+prompt,
    "Style : "+style,
    "Durée cible : "+duration,
    "Langue : "+language,
    "Format : "+format,
    "Qualité souhaitée : Premium",
    "",
    "À produire : scénario, découpage des scènes, visuels, voix off, musique, sous-titres et montage.",
    "",
    "Note : ce brief est préparé par le site. La génération vidéo nécessite la connexion d'un fournisseur API."
  ].join("\n");
  resultText.textContent=currentBrief;
  resultPanel.hidden=false;
  resultPanel.scrollIntoView({behavior:"smooth",block:"nearest"});
});

document.getElementById("copyBrief").addEventListener("click",async()=>{
  try{
    await navigator.clipboard.writeText(currentBrief);
    showToast("Brief copié dans le presse-papiers.");
  }catch(error){
    showToast("Copie indisponible : sélectionnez le texte manuellement.");
  }
});

document.getElementById("langSwitch").addEventListener("click",()=>{
  showToast("La version anglaise complète sera ajoutée dans une prochaine étape.");
});
